SPEEDTRACK GPS BY MATTIX — VERSIONE PRONTA PER NETLIFY DROP

CONTENUTO
- index.html: app completa in un solo file HTML, con stile e JavaScript inclusi
- manifest.webmanifest e sw.js: installazione PWA e cache offline

PUBBLICAZIONE PIÙ SEMPLICE DAL TELEFONO
1. Estrai questo ZIP sul telefono con l'app File/archivio.
2. Apri https://app.netlify.com/drop dal browser e accedi/registrati.
3. Carica la CARTELLA ESTRATTA (quella che contiene index.html) se il selettore lo permette.
4. Se Netlify Drop non consente di caricare una cartella da Android, crea un nuovo sito Netlify e usa il metodo di deploy manuale disponibile nel pannello; in alternativa usa Cloudflare Pages tramite upload diretto se disponibile nel tuo account.
5. Apri il link HTTPS generato. Premi “Avvia GPS” e consenti la posizione.

IMPORTANTE
- Il GPS nel browser funziona solo su HTTPS o localhost.
- Non è un tachimetro certificato: le misurazioni possono essere imprecise.
- Non usare il telefono in mano mentre guidi.
- Questo è il sito/PWA. Non è un APK Android già compilato.
- Non contiene Firebase né sincronizzazione cloud: i tragitti sono salvati sul dispositivo.
